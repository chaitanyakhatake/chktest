<?php
/*
Plugin Name: Rest Api Test
Description: This is test plugin for custom api!
Version: 1.0
Author: Chaitanya
*/

//create this custom table


function ck_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'form_submissions';

    $sql = "CREATE TABLE $table_name (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      firstname varchar (100) NOT NULL,
      lastname varchar (100) NOT NULL,
      PRIMARY KEY  (id)
    )";
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
   
}

register_activation_hook( __FILE__, 'ck_create_table' );

// Generate API Token by Username and Password
function generate_api_token_by_credentials($request) {
    // Get username and password from the request
    $username = $request->get_param('username');
    $password = $request->get_param('password');
    // Check if username and password are provided
    if (!$username || !$password) {
        return new WP_Error('missing_credentials', 'Username and password are required', array('status' => 400));
    }
    // Authenticate user
    $user = wp_authenticate($username, $password);
    if (is_wp_error($user)) {
        return new WP_Error('authentication_failed', 'Authentication failed', array('status' => 401));
    }
    // Generate a random token
    $token = wp_generate_password(64, false);
    // Store the token in user meta
    update_user_meta($user->ID, 'api_token', $token);
    // Return the generated token
    return array(
        'token' => $token
    );
}
// Register endpoint for token generation by credentials
add_action('rest_api_init', function () {
    register_rest_route('custom/v1', '/generate-token', array(
        'methods' => 'POST',
        'callback' => 'generate_api_token_by_credentials',
        'permission_callback' => function () {
            return true;
        },
    ));
});

// End point for form data store
function custom_register_form_submission_endpoint() {
    register_rest_route('custom/v1', '/formsubmit', array(
        'methods' => 'POST',
        'callback' => 'custom_form_submission_callback',
        'permission_callback' => function () {
            return true;
        },
    ));
}
add_action('rest_api_init', 'custom_register_form_submission_endpoint');

function custom_form_submission_callback($request) {
    $firstname = $request->get_param('firstname');
    $lastname = $request->get_param('lastname');
   
    /********Check Token in DB**********/
    $authorization_header = $request->get_header('Authorization');
    $token = substr($authorization_header, 7);
    $user_query = new WP_User_Query(array(
        'meta_query' => array(
            array(
                'key' => 'api_token',
                'value' => $token,
                'compare' => '='
            )
        )
    ));

    $users = $user_query->get_results();
    if (!empty($users)) {
        $apiuser = $users[0]->ID;
        $chktokn = get_user_meta($apiuser, 'api_token', true);
    }
    /********Check Token in DB**********/
    if ($authorization_header && strpos($authorization_header, 'Bearer') === 0) {
        // Extract the token from the Authorization header
        $token = substr($authorization_header, 7);
        if ($token === $chktokn) {
           if($firstname!=""&& $lastname!="")
		   {
			   //insert data in database
			 global $wpdb;
			 $dbinsert = $wpdb->insert("wp_form_submissions", [

                "firstname" => $firstname,

                "lastname" => $lastname,

            ]);

            if ($dbinsert == true) {

                $status = "Success";

            } else {

                $status = "Something went wrong";

            }   
		   }
		   else{
			   $status="Please enter firstanme and lastname";
		   }
        } else {
            // Token is invalid, return error response
            $status="invalid_token";
        }
    } else {
        // Authorization header missing or invalid, return error response
        $status="missing_authorization_header";
    }
	
     $return_status = array('status'=>$status);
	 
     echo json_encode($return_status);
}   

// End point for fetech stored data
function custom_register_getdata_endpoint() {
    register_rest_route('custom/v1', '/getformdata', array(
        'methods' => 'GET',
        'callback' => 'custom_getdata_callback',
        'permission_callback' => function () {
            return true;
        },
    ));
}
add_action('rest_api_init', 'custom_register_getdata_endpoint');

function custom_getdata_callback($request) {
	
        /********Check Token in DB**********/
    $authorization_header = $request->get_header('Authorization');
    $token = substr($authorization_header, 7);
    $user_query = new WP_User_Query(array(
        'meta_query' => array(
            array(
                'key' => 'api_token',
                'value' => $token,
                'compare' => '='
            )
        )
    ));

    $users = $user_query->get_results();
    if (!empty($users)) {
        $apiuser = $users[0]->ID;
        $chktokn = get_user_meta($apiuser, 'api_token', true);
    }
    /********Check Token in DB**********/
    if ($authorization_header && strpos($authorization_header, 'Bearer') === 0) {
        // Extract the token from the Authorization header
        $token = substr($authorization_header, 7);
        if ($token === $chktokn) {
			global $wpdb;
		   $table_name = $wpdb->prefix . 'form_submissions';
           $results = $wpdb->get_results( "SELECT * FROM $table_name" );
		   $status=$results ;
        } else {
            // Token is invalid, return error response
            $status="invalid_token";
        }
    } else {
        // Authorization header missing or invalid, return error response
        $status="missing_authorization_header";
    }
	
     $return_status = array('status'=>$status);
	 
     echo json_encode($return_status);
} 

?>